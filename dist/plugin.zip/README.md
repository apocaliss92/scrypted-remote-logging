# Scrypted remote logging

https://github.com/apocaliss92/scrypted-remote-logging - For requests and bugs
